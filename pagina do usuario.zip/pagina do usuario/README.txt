Olá professor. Se Não funcionar, é porquê o nosso banco de dados está na porta 3307. 
Para resolver isso, basta ir em "db_connection.php" e excluir a linha 6.